

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registerservlet
 */
@WebServlet("/Registerservlet")
public class Registerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registerservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String surname=request.getParameter("surname");
		String mob=request.getParameter("mob");
		PrintWriter out=response.getWriter();
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","password");
			PreparedStatement pt=con.prepareStatement("insert into register values('"+username+"','"+password+"','"+surname+"','"+mob+"')");
			 int i=pt.executeUpdate();
			 if(i>0)
			 {
				 request.getRequestDispatcher("login.html").forward(request, response);
				 out.print("registration successful");
			 }
			 else
			 {
				out.print("registration failed.....!");
			 }
			
		} catch (Exception e) {
			out.print(e);
		}
	}

}

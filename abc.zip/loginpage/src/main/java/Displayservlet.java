

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Displayservlet
 */
@WebServlet("/Displayservlet")
public class Displayservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Displayservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		try {
	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","password");
	Statement st=con.createStatement();
	 ResultSet rs=st.executeQuery("select * from register");
	 out.println("<table border=1 width=50% height=50%>");  
	 out.println("<tr><th>username</th><th>surname</th><th>mob</th><tr>");
	while(rs.next())
	{
		out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td></tr>");
	}
	con.close();
	out.print("</table>");
	out.print("<a href='login.html'>Back to LoginPage</a>");
} catch (Exception e) {
	out.print(e);
}
		
	}
}

	





import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Loginservlet
 */
@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s1=request.getParameter("user");
		String s2=request.getParameter("password");
		PrintWriter out=response.getWriter();
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","password");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from profile where fname='"+s1+"' and roll='"+s2+"'");
			if(rs.next()) {
				request.getRequestDispatcher("add.html").forward(request, response);
				out.print("login successfully...");
			}
			else {
				request.getRequestDispatcher("login.html").include(request, response);
			}
			
			
		} catch (Exception e) {
			out.print(e);
		}
	}

}

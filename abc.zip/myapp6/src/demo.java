

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class demo
 */
@WebServlet("/demo")
public class demo extends GenericServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see GenericServlet#GenericServlet()
     */
    public demo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
	
	String fname=request.getParameter("fname");	
	String lname=request.getParameter("lname");
	String roll=request.getParameter("roll");
	String address=request.getParameter("address");
	PrintWriter out=response.getWriter();
	try {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","password");
		PreparedStatement st=con.prepareStatement("insert into profile values('"+fname+"','"+lname+"','"+roll+"','"+address+"')");
		int i=st.executeUpdate();
		if(i>0) {
			request.getRequestDispatcher("login.html").forward(request, response);
		}
		else {
			request.getRequestDispatcher("stud2.html").include(request, response);
		}
		
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	}

}
